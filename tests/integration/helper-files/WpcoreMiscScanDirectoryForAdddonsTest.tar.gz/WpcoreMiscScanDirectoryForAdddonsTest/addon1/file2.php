<?php
/**
 * @package MyPackage
 * @version 1.0.0
 */                                
/*                                
 * Plugin Name: My Other Package 
 * Plugin URI: http://wordpress.org/test/my-other-package/  
 * Description: My text. 
 * Author: Author Name  
 * Version: 1.1.0  
 * Author URI: http://wordpress.org/author/test123  
 */
