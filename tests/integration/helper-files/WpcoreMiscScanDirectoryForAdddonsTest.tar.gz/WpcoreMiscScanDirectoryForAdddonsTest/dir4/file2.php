<?php
/*                                
 * Name: My Package
 * URI: http://wordpress.org/test/my-package/
 * Au thor: Author Name                                
 * Ver sion: 1.0.0
 */
